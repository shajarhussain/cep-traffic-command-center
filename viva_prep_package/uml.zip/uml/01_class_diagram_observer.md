# Figure 1: Observer Pattern Class Diagram

> **Requirement covered:** CLO 3 Task 2 — Observer Pattern
> **Code evidence:** `IEventSubscriber.ts`, `EventBus.ts`, `BaseIdempotentSubscriber.ts`, `AlertService.ts`, `LoggingService.ts`, `DashboardService.ts`, `ReportingService.ts`

---

## Diagram

```mermaid
classDiagram
    direction TB

    class IEventSubscriber {
        <<interface>>
        +name: string
        +supportedEventTypes: string[]
        +handle(envelope: EventEnvelope) Promise~void~
    }

    class BaseIdempotentSubscriber {
        <<abstract>>
        - _duplicateIgnoredCount: number
        - _processedCount: number
        +handle(envelope: EventEnvelope) Promise~void~
        #process(envelope: EventEnvelope)* Promise~void~
    }

    class EventBus {
        -subscribers: Map~string, Set~IEventSubscriber~~
        +subscribe(eventType: string, subscriber: IEventSubscriber) void
        +unsubscribe(eventType: string, subscriber: IEventSubscriber) void
        +publish(envelope: EventEnvelope) Promise~void~
    }

    class AlertService {
        +name: string
        +supportedEventTypes: string[]
        #process(envelope: EventEnvelope) Promise~void~
    }

    class LoggingService {
        +name: string
        +supportedEventTypes: string[]
        #process(envelope: EventEnvelope) Promise~void~
    }

    class DashboardService {
        +name: string
        +supportedEventTypes: string[]
        #process(envelope: EventEnvelope) Promise~void~
    }

    class ReportingService {
        +name: string
        +supportedEventTypes: string[]
        #process(envelope: EventEnvelope) Promise~void~
    }

    IEventSubscriber <|.. BaseIdempotentSubscriber : implements
    BaseIdempotentSubscriber <|-- AlertService : extends
    BaseIdempotentSubscriber <|-- LoggingService : extends
    BaseIdempotentSubscriber <|-- DashboardService : extends
    BaseIdempotentSubscriber <|-- ReportingService : extends
    EventBus o-- IEventSubscriber : holds subscribers as interface references
```
